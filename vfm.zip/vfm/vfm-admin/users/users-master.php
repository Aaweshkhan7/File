<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '',
    'role' => 'superadmin',
  ),
);
